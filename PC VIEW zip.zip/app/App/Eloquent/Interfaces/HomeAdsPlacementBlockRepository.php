<?php

namespace App\App\Eloquent\Interfaces;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface HomeAdsPlacementBlockRepository.
 *
 * @package namespace App\App\Eloquent\Interfaces;
 */
interface HomeAdsPlacementBlockRepository extends RepositoryInterface
{
    //
}
