<?php

namespace App\App\Eloquent\Interfaces;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface AppDeveloperRepository.
 *
 * @package namespace App\App\Eloquent\Interfaces;
 */
interface AppDeveloperRepository extends RepositoryInterface
{
    //
}
