<?php

namespace App\App\Eloquent\Interfaces;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface AppFeaturedPostRepository.
 *
 * @package namespace App\App\Eloquent\Interfaces;
 */
interface AppFeaturedPostRepository extends RepositoryInterface
{
    //
}
