<?php

namespace App\App\Eloquent\Interfaces;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface AppImageRepository.
 *
 * @package namespace App\App\Eloquent\Interfaces;
 */
interface AppImageRepository extends RepositoryInterface
{
    //
}
