<?php

namespace App\App\Eloquent\Interfaces;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface HomeAdsPlacementBlockableRepository.
 *
 * @package namespace App\App\Eloquent\Interfaces;
 */
interface HomeAdsPlacementBlockableRepository extends RepositoryInterface
{
    //
}
