<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Configuration\\Providers\\ConfigurationServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Configuration\\Providers\\ConfigurationServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);