<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Link\\Providers\\LinkServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Link\\Providers\\LinkServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);