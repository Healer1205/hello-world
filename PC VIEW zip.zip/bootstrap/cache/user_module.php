<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\User\\Providers\\AuthServiceProvider',
    1 => 'Modules\\User\\Providers\\UserServiceProvider',
    2 => 'Modules\\User\\Providers\\EventServiceProvider',
    3 => 'Modules\\User\\Providers\\ComposerServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\User\\Providers\\AuthServiceProvider',
    1 => 'Modules\\User\\Providers\\UserServiceProvider',
    2 => 'Modules\\User\\Providers\\EventServiceProvider',
    3 => 'Modules\\User\\Providers\\ComposerServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);