<?php

namespace Modules\User\Eloquent\Interfaces;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface UserUploadRepository.
 *
 * @package namespace Modules\User\Eloquent\Interfaces;
 */
interface UserUploadRepository extends RepositoryInterface
{
    //
}
