<?php

return [

    'status.active'      => 'Active',
    'status.banned'      => 'Banned',
    'status.suspend'     => 'Suspend',
    'status.unconfirmed' => 'Unconfirmed',

];