<?php

namespace Modules\Review\Eloquent\Interfaces;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface ReviewRepository.
 *
 * @package namespace Modules\Review\Eloquent\Interfaces;
 */
interface ReviewRepository extends RepositoryInterface
{
    //
}
