<?php

return [

    'status.published' => 'Published',
    'status.pending'   => 'Pending',
    'status.is_draft'  => 'Draft'

];
