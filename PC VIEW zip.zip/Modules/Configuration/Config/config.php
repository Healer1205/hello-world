<?php

return [
    'name' => 'Configuration',


    'config_timezone_cache_key' => 'config_timezone_lists'
];
