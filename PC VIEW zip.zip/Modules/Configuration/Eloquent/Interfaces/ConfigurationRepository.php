<?php

namespace Modules\Configuration\Eloquent\Interfaces;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface ConfigurationRepository.
 *
 * @package namespace Modules\Configuration\Eloquent\Interfaces;
 */
interface ConfigurationRepository extends RepositoryInterface
{
    //
}
